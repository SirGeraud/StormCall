//
//  Temperature.swift
//  Weather App
//
//  Created by Lyndon Applewhite on 3/28/21.
//

import Foundation

struct Temperature: Codable {
    var min: Double
    var max: Double
}
