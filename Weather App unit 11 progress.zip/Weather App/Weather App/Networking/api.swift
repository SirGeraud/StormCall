//
//  api.swift
//  Weather App
//
//  Created by Lyndon Applewhite on 3/28/21.
//

import Foundation

struct API {
    static let key = "2cf9a85f058da1dca88bd6d70998b9a6"
}
