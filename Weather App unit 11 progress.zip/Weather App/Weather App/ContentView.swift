//
//  ContentView.swift
//  Weather App
//
//  Created by Lyndon Applewhite on 3/28/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
