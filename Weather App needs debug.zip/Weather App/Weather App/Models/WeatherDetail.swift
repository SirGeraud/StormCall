//
//  WeatherDetail.swift
//  Weather App
//
//  Created by Lyndon Applewhite on 3/28/21.
//

import Foundation

struct WeatherDetail: Codable {
    var main: String
    var description: String
    var icon: String
}
